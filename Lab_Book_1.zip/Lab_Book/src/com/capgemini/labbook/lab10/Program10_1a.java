package com.capgemini.labbook.lab10;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Program10_1a {
	
	public static void main(String[] args) throws IOException {
		Properties p = new Properties();
		FileInputStream in = new FileInputStream("PersonProps.properties");
		p.load(in);
		System.out.println(p);
	}
}
