package com.capgemini.labbook.lab13;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread implements Runnable {
	static FileOutputStream fos;
	static FileInputStream fis;
	public CopyDataThread(FileOutputStream fos, FileInputStream fis) {
		// TODO Auto-generated constructor stub
		this.fos = fos;
		this.fis = fis;
	}
	
	@Override
	public void run(){
		// TODO Auto-generated method stub
		int count = 0;
		try {
			int a = fis.read();
			while(a != -1) {
				if(count == 10) {
					Thread.sleep(5000);
					System.out.println("10 characters are copied");
					count = 0;
				}
				System.out.println(a);
				fos.write((char)a);
				count++;
				a = fis.read();
			}
		}
		catch(Exception e) {
			
		}
	}
}
