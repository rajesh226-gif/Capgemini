package com.capgemini.labbook.lab5.eis.pl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

import com.capgemini.labbook.lab5.eis.bean.Employee;
import com.capgemini.labbook.lab5.eis.service.IEmployeeService;
import com.capgemini.labbook.lab5.eis.service.ImplEmployeeService;
import com.capgemini.labbook.lab6.eis.exception.EmployeeException;

public class EmployeeTest {
	public static void main(String[] args) throws EmployeeException{
		
		Scanner sc = new Scanner(System.in);
		
		int empId;
		String empName;
		double empSal;
		String empDesig;
		String ans;
		
		IEmployeeService imples = new ImplEmployeeService();
		Employee emp;
		
		do {
			System.out.println("Enter the employee details\nEmployee Id : ");
			empId = sc.nextInt();
			System.out.println("Employee Name : ");
			empName = sc.next();
			System.out.println("Salary : ");
			empSal = sc.nextDouble();
			if(empSal < 3000)
				throw new EmployeeException();
			System.out.println("Employee Designation : ");
			empDesig = sc.next();
			System.out.println("Choose from below : \n1. Get Insurance scheme.\n2. Display all details.\n3. Get all Employees\n4. Delete Employee Details\n5. Get Employees Details based on Insurance scheme\n6. Sort employees based on salary");
			int choice = sc.nextInt();
			
			emp = new Employee(empId, empName, empSal, empDesig);
			imples.addEmployee(emp);
			switch(choice) {
				case 1 : String res = imples.getInsuranceScheme(empSal, empDesig);
						 System.out.println(res);
						 break;
				case 2 : emp = imples.getDetails(emp);
						 System.out.println(emp);
						 break;
				case 3 : HashMap hs = new HashMap();
						 hs = imples.getAllEmployees();
						 System.out.println(hs);
						 break;
				case 4 : imples.deleteEmployee(emp.getEmpId());
						 HashMap hs1 = new HashMap();
						 hs1 = imples.getAllEmployees();
						 System.out.println(hs1);
						 break;
				case 5 : System.out.println("Enter the scheme : ");
						 String sch = sc.next();
						 HashMap hs2 = new HashMap();
						 hs2 = imples.getEmpsByScheme(sch);
						 System.out.println(hs2);
						 break;
				case 6 : TreeSet<Employee> lst = new TreeSet<>();
						 lst = imples.getEmpBySal();
						 for(Employee ts : lst)
							 System.out.println(ts);
						 break;
				default : System.out.println("Incorrect selection");
						  break;
			}
			System.out.println("Do you want to continue? yes/no");
			ans = sc.next();
		}while(ans.equals("yes") || ans.equals("Yes") || ans.equals("YES"));
	}	
}

