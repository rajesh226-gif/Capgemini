package com.capgemini.labbook.lab3;

import java.util.Scanner;

public class Program3_1Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String : ");
		String str = sc.nextLine();
		System.out.println("Select the choice :\n 1. Add the String to itself\n" + 
				"2. Replace odd positions with #\n" + 
				"3.	Remove duplicate characters in the String\n" + 
				"4.	Change odd characters to upper case\n");
		Program3_1 p = new Program3_1();
		int uc = sc.nextInt();
		
		String res;
		switch(uc) {
			case 1 : res = p.addStringToSelf(str);
					 System.out.println(res);
					 break;
			case 2 : res = p.replaceOddPos(str);
					 System.out.println(res);
					 break;
			case 3 : res = p.removeDuplicates1(str);
					 System.out.println(res);
					 break;
			case 4 : res = p.changeOddChar(str);
					 System.out.println(res);
					 break;
		}
		}
		
}

