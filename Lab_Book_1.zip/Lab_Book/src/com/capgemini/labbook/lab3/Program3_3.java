package com.capgemini.labbook.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class Program3_3 {
	public String printDuration(String input) {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		//Almost every class in java.time package provides parse() method to parse the date or time
		LocalDate enteredDate = LocalDate.parse(input,formatter);
		
		LocalDate end = LocalDate.now();
		
		Period period = enteredDate.until(end);
		return period.getDays()+"/"+period.getMonths()+"/"+period.getYears();		
	}
}
