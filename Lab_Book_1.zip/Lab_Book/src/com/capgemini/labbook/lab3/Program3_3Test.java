package com.capgemini.labbook.lab3;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Program3_3Test {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter date in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
		Program3_3 p = new Program3_3();
		String str = p.printDuration(input);
		String[] res = str.split("/");
		System.out.println("Days : "+res[0]);
		System.out.println("Months : "+res[1]);
		System.out.println("Years : "+res[2]);
	}
}
