package com.capgemini.labbook.lab2;

import java.util.Scanner;

public class Program2_2 {
	public static void main(String[] args) {
		//Scanner sc = new Scanner(System.in);
		//System.out.println("Enter a number :");
		int num = Integer.parseInt(args[0]);
		//System.out.println(num);
		if(num < 0)
			System.out.println("The number you entered is a negative number");
		else if(num > 0)
			System.out.println("The number you entered is a positive number");
		//sc.close();
	}
}
