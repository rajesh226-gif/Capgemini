package com.capgemini.labbook.lab2;

public class PersonMain {
	public static void main(String[] args) {
		Person p = new Person("laxmi Prasanna","pujari",Gender.f,"7898586545");
		//p.print();
		p.printDetails();
	}
}
