package com.capgemini.labbook.lab7;

import java.util.Arrays;

public class Program7_1 {
	public static void main(String[] args) {
		String[] arr = {"grapes","mango","banana","apple"};
		Arrays.sort(arr);
		for(String i : arr)
			System.out.println(i);
	}
}
