package com.capgemini.labbook.lab4;

import java.util.Calendar;
import java.util.Scanner;

public class Test extends Account {
	Test(double sal,Person p){
		super(sal,p);
	}
	
	public static void main(String[] args) throws MyException{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter age of the Smith:");
		int age = sc.nextInt();
		System.out.println("Current Accounts status");
		Person p1 = new Person("Smith",age);
		if(age < 15)
			throw new MyException();
		Test a1 = new Test(2000,p1);
		System.out.println(a1.toString());
		Person p2 = new Person("Kathy",36);
		Test a2 = new Test(3000,p2);
		System.out.println(a2.toString());
		a1.deposit(2000);;
		System.out.println();
		//System.out.println(bal);
		//bal += 2000;
		//System.out.println(bal);
		//a1.setBalance(bal);
		System.out.println("After deposit of 2000 in Smith's account");
		System.out.println(a1.toString());
		System.out.println();
		System.out.println("After withdraw of 2000 in Kathy's account");
		SavingsAccount sa = new SavingsAccount(2000, p2); 
		sa.withdraw(3000);
		System.out.println(a2.toString());
		
	}

	@Override
	public void withdraw(double d) {
		// TODO Auto-generated method stub
		
	}
}
class MyException extends Exception{
	public String getMessage() {
		return "Employee can't have age < 15";
	}
}