package com.capgemini.labbook.lab4;

public class CurrentAccount extends Account{
	double overdraftLimit = 1000;
	public void withdraw(double d) {
		//System.out.println(balance);
		if(overdraftLimit > d)
			balance -= d;
	}
}
