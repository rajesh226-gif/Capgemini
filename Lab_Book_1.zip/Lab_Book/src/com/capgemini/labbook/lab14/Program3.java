package com.capgemini.labbook.lab14;

import java.util.function.BiFunction;

public class Program3 {
	public static void main(String[] args) {
		

		/*Predicate<Integer> isPositive1 = (x) -> x > 0 ? true : false;
		System.out.println("Predicate positive "+isPositive1.test(-5));
		*/
		BiFunction<String,String,Boolean> p = (s1, s2) ->{
			String uname = "root", pwd = "root";
			if(s1.equals(uname) && s2.equals(pwd))
				return true;
			return false;
		};
		System.out.println(p.apply("root","rot"));
	}
}
interface test{
	public abstract boolean validate(String uname, String pwd);
}