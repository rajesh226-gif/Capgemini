package com.capgemini.labbook.lab14;

import java.util.function.Function;

public class Program5 {
	public static void main(String[] args) {
		Function<Integer, Integer> emp = Program5Help :: fact;
		System.out.println("EmpId : "+emp.apply(5));
	}
}
