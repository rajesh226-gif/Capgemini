package com.capgemini.labbook.lab9;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class PersonTest {
	static Person p;
	@BeforeClass
	public static void preInit() {	
		p = new Person("laxmi prasanna","pujari",Gender.f,"29101997");
	}
	
	@Test
	public void testGetFirstName() {
		Assert.assertEquals("laxmi prasanna", p.getFirstName());
	}
	@Test
	public void testGetLastName() {
		Assert.assertEquals("pujari", p.getLastName());
	}
	@Test
	public void testGetGender() {
		Assert.assertEquals("f", p.gender.toString());
	}
	@Test
	public void testGetPhono() {
		Assert.assertEquals("29101997", p.getPhono());
	}
	@Test
	public void testToString() {
		String str = "Person [firstName=" + p.getFirstName() + ", lastName=" + p.getLastName() + ", phono=" + p.getPhono() + ", gender=" + p.gender + "]";
		Assert.assertEquals(str, p.toString());
	}
}
