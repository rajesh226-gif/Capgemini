package com.capgemini.labbook.lab9;
enum Gender{M,f};
public class Person {
	
	String firstName;
	String lastName;
	String phono;
	Gender gender;
	public String getFirstName() {
		return firstName;
	}
	public Person(String firstName, String lastName, Gender gen, String phono) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phono = phono;
		this.gender = gen;
	}
	public String getPhono() {
		return phono;
	}
	public void setPhono(String phono) {
		this.phono = phono;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Person() {
		
	}
	public Person(String firstName, String lastName, Gender gender) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	
	
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName + ", phono=" + phono + ", gender=" + gender
				+ "]";
	}
	public void print() {
		System.out.println("Person Details :\n__________________\n\nFirst Name : "+ firstName+"\nLast Name : "+lastName+"\nGender : "+gender);
	}
	public void printDetails() {
		System.out.println("Person Details :\n__________________\n\nFirst Name : "+ firstName+"\nLast Name : "+lastName+"\nGender : "+gender+"\nPhone Number : "+phono);
	}
}
