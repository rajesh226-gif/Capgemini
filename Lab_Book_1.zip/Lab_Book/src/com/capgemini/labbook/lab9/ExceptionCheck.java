package com.capgemini.labbook.lab9;

public class ExceptionCheck {

}
