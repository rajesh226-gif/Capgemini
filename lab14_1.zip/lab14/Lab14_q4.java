package com.cg.assignments.lab14;

import java.util.function.Supplier;



public class Lab14_q4 
{
	public static void main(String[] args) 
	{
		Supplier<Sample> dc = Sample::new;
		Sample s = dc.get();
		s.setId(101);
		s.setName("Raju");
		System.out.println("Sample Details : "+s.getId()+"\t"+s.getName());
	}
}


class Sample
{
	int id;
	String name;
	
	
	
	public Sample() {
		super();
	}
	public Sample(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
