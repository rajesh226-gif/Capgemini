package com.cg.assignments.lab14;

import java.util.function.Function;

public class Lab14_q2 {
public static void main(String[] args) {
	Function<String, String> str=(s)->{
		int l=s.length();String s1="";
		for(int i=0;i<l-1;i++)
		{
		char ch=s.charAt(i);
	    s1=s1+ch+" ";
		}
		s1=s1+s.charAt(l-1);
		return s1;
	};
	System.out.println(str.apply("pratik"));
}
}
