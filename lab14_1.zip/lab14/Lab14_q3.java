package com.cg.assignments.lab14;

import java.util.Scanner;
import java.util.function.BiPredicate;

public class Lab14_q3 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter username");
	String uname=sc.next();
	System.out.println("enter password");
	String pswrd=sc.next();
	BiPredicate<String, String> pre=(s,s1)->{
		boolean result=s.equals("Pratik")&&s1.equals("iama");
		return result;
	};
	System.out.println(pre.test(uname, pswrd));
}
}
