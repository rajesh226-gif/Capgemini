package com.cg.assignments.lab14;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.cg.eis.bean.Employee;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashSet;

public class Lab14_q6_EmployeeRepository {
public static void main(String[] args) {
	Lab14_q6_Employee emp=new Lab14_q6_Employee(101,"rose","kumar","rose@gmail.com","89324687",LocalDate.of(1998, 4, 17),"mnky",20000.0,104,new lab14_6_Department(102,"Forest",101));
	Lab14_q6_Employee emp1=new Lab14_q6_Employee(102,"gulaab","kumar","gulaab@gmail.com","809324687",LocalDate.of(2015, 5, 9),"mdasd",20000.0,104,new lab14_6_Department(103,"acas",102));
	Lab14_q6_Employee emp2=new Lab14_q6_Employee(103,"paudha","kumar","paudha@gmail.com","809324687",LocalDate.of(2020, 1, 9),"mdasd",20000.0,0,new lab14_6_Department(104,"head",1003));
	Lab14_q6_Employee emp4=new Lab14_q6_Employee(104,"mitti","kumar","mitti@gmail.com","809324687",LocalDate.of(2020, 1, 9),"mdasd",20000.0,108,new lab14_6_Department(104,"head",1003));
	List<Lab14_q6_Employee> coll = new ArrayList<>();
	coll.add(emp);
	coll.add(emp1);
	coll.add(emp2);
	coll.add(emp4);
	
	Stream<Lab14_q6_Employee> salSum = coll.stream();
	Stream<Double> sal = coll.stream().map((s)->s.getSalary());
	System.out.println(sal.reduce((a,b)->a+b).get());
	
	Stream<Lab14_q6_Employee> str1=coll.stream();
	Stream<String> depName = str1.map((s)->s.getDepartment().getDepartName());
	depName.forEach((e)->
	{
		Stream<Lab14_q6_Employee> str2 = coll.stream();
		System.out.println(e+" "+str2.filter(em->em.getDepartment().getDepartName().equals(e)).count());
	});
	
	Stream<Lab14_q6_Employee> str3 = coll.stream();
	str3.filter((s)->s.getManagerId().equals(0)).forEach(System.out::println);
	
	Stream<Lab14_q6_Employee> date = coll.stream();
	date.forEach((e)->{
		LocalDate now = LocalDate.now();
		Period p = Period.between(e.getHireDate(), now);
		System.out.println(e.getEmpFname()+"\t"+p.getDays()+"days "+p.getMonths()+"months "+p.getYears()+"years");
	});
	
	Stream<Lab14_q6_Employee> print = coll.stream();
	print.forEach((e)->{
		System.out.println(e.getEmpFname()+" "+e.getEmpLname()+" "+e.getHireDate()+" "+e.getHireDate().getDayOfWeek());
	});
	
	Stream<Lab14_q6_Employee> print2 = coll.stream();
	DayOfWeek fri = DayOfWeek.FRIDAY;
	print2.filter((e)->e.getHireDate().getDayOfWeek().equals(fri)).forEach(System.out::println);;
	
	Stream<Lab14_q6_Employee> str4=coll.stream();
	str4.forEach((e)->{
		System.out.println(e.getEmpFname()+" "+e.getEmpLname()+" reports to "+e.getManagerId());
	});
	
	Stream<Lab14_q6_Employee> str5=coll.stream();
	str5.forEach((e)->{
		System.out.println(e.getEmpFname()+" "+e.getEmpLname()+e.getSalary()+" "+(e.getSalary()+0.15*e.getSalary()));
	});
	
	Stream<Lab14_q6_Employee> str6=coll.stream();
	str6.filter(s->s.getManagerId().equals(0)).forEach(System.out::println);
	
	/*List<Integer> listId=coll.stream().map(Lab14_q6_Employee::getManagerId).collect(Collectors.toList());
	List<Lab14_q6_Employee> eList=coll.stream().filter(i1->i1.getEmpId()==listId.get(0)).collect(Collectors.toList());
	System.out.println(listId);
	System.out.println(eList);
	System.out.println("111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");*/
	Scanner sc = new Scanner(System.in);
	String fname,lname;
	fname = "mitti";
	lname = "kumar";
	
	System.out.println("-------------------------------------------------------------------------------------------------");
	Integer mgr = (Integer)coll.stream().filter((employ)->employ.getEmpFname().equals(fname)&&employ.getEmpLname().equals(lname)).map((empl)->empl.getEmpId()).collect(Collectors.toList()).get(0);
	System.out.println(mgr);
	coll.stream().filter((employ)->employ.getManagerId().equals(mgr)).forEach(System.out::println);
	System.out.println("-------------------------------------------------------------------------------------------------");
	
	
	coll.stream().sorted((i1,i2)->
	{
		int a=i1.getEmpId();
		int b=i2.getEmpId();
		if(a>b)
			return 1;
		else if(a<b)return -1;
		else return 0;
		
	}).forEach(System.out::println);
	
	coll.stream().sorted((i1,i2)->
	{
		int a=i1.getDepartment().getDepartId();
		int b=i2.getDepartment().getDepartId();
		if(a>b)
			return 1;
		else if(a<b)return -1;
		else return 0;
		
	}).forEach(System.out::println);
	
	System.out.println("/n");
	coll.stream().sorted((i1,i2)->
	{
		String a=i1.getEmpFname();
		String b=i2.getEmpFname();
		if(a.compareTo(b)>0)
			return 1;
		else if(a.compareTo(b)<0)return -1;
		else return 0;
		
	}).forEach(System.out::println);
	
	
}
}
