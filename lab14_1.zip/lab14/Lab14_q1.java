package com.cg.assignments.lab14;

import java.util.function.BiFunction;

public class Lab14_q1 
{
public static void main(String[] args) {
	BiFunction<Integer,Integer,Double> pow = (x,y)->Math.pow(x, y);
	System.out.println(pow.apply(2, 3));
}
}
