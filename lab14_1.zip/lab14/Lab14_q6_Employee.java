package com.cg.assignments.lab14;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;



public class Lab14_q6_Employee {
Integer empId;
String empFname;
String empLname;
String email;
String pNo;
LocalDate hireDate;
String designation;
Double salary;
Integer managerId;
lab14_6_Department department;
public Lab14_q6_Employee(Integer empId, String empFname, String empLname, String email, String pNo, LocalDate hireDate,
		String designation, Double salary, Integer managerId, lab14_6_Department department) {
	super();
	this.empId = empId;
	this.empFname = empFname;
	this.empLname = empLname;
	this.email = email;
	this.pNo = pNo;
	this.hireDate = hireDate;
	this.designation = designation;
	this.salary = salary;
	this.managerId = managerId;
	this.department = department;
}
public Lab14_q6_Employee() {
	super();
}
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public String getEmpFname() {
	return empFname;
}
public void setEmpFname(String empFname) {
	this.empFname = empFname;
}
public String getEmpLname() {
	return empLname;
}
public void setEmpLname(String empLname) {
	this.empLname = empLname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getpNo() {
	return pNo;
}
public void setpNo(String pNo) {
	this.pNo = pNo;
}
public LocalDate getHireDate() {
	return hireDate;
}
public void setHireDate(LocalDate hireDate) {
	this.hireDate = hireDate;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public Double getSalary() {
	return salary;
}
public void setSalary(Double salary) {
	this.salary = salary;
}
public Integer getManagerId() {
	return managerId;
}
public void setManagerId(Integer managerId) {
	this.managerId = managerId;
}
public lab14_6_Department getDepartment() {
	return department;
}
public void setDepartment(lab14_6_Department department) {
	this.department = department;
}
@Override
public String toString() {
	return "Lab14_q6_Employee [empId=" + empId + ", empFname=" + empFname + ", empLname=" + empLname + ", email="
			+ email + ", pNo=" + pNo + ", hireDate=" + hireDate + ", designation=" + designation + ", salary=" + salary
			+ ", managerId=" + managerId + ", department=" + department + "]";
}




}
