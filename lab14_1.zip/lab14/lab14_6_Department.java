package com.cg.assignments.lab14;

public class lab14_6_Department {
	Integer departId;
	String departName;
	Integer managerId;
	public lab14_6_Department(Integer departId, String departName, Integer managerId) {
		super();
		this.departId = departId;
		this.departName = departName;
		this.managerId = managerId;
	}
	public Integer getDepartId() {
		return departId;
	}
	public void setDepartId(Integer departId) {
		this.departId = departId;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	public Integer getManagerId() {
		return managerId;
	}
	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}
	@Override
	public String toString() {
		return "lab14_6_Department [departId=" + departId + ", departName=" + departName + ", managerId=" + managerId
				+ "]";
	}
	
	
	
	
	
}
