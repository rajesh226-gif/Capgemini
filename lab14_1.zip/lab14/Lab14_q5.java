package com.cg.assignments.lab14;

import java.util.Scanner;
import java.util.function.Function;
import java.util.function.Supplier;

public class Lab14_q5 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	Supplier<Sample1> fact=Sample1::new;
	Function<Integer, Integer> fa = fact.get()::factorial;
	System.out.println(fa.apply(n));
}
}
class Sample1
{
int factorial(int n)
{
	int f=1;
	for(int i=1;i<=n;i++)
		f=f*i;
	return f;
}
}
