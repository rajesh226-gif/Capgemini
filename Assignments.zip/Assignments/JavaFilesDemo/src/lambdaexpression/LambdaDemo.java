package lambdaexpression;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class LambdaDemo {
	public static void main(String[] args) {
		/*MaxFinderImpl mf = new MaxFinderImpl();
		mf.findMax(5, 6);*/
		
		MaxFinder mf = (x, y) -> x > y ? x : y; //lambda expressions can implement the interfaces with only one abstract method, and is called functional interface
		System.out.println(mf.findMax(5, 6));
		
		BiFunction<Integer, Integer, Integer> max1 = (x, y) -> x > y ? x : y; 
		System.out.println(max1.apply(20, 40));
		
		TestInter isEven = (x) -> x % 2 == 0 ? true : false;//(x) can also be written as x (braces are optional)
		System.out.println(isEven.test(6));
		
		Predicate<Integer> isEven1 = x -> x % 2 == 0 ? true : false;
		System.out.println("Predicate even "+isEven1.test(89));
		
		TestInter isPositive = (x) -> x > 0 ? true : false;
		System.out.println(isPositive.test(-5));
		
		Predicate<Integer> isPositive1 = (x) -> x > 0 ? true : false;
		System.out.println("Predicate positive "+isPositive1.test(-5));
		
		Consumer<String> consumer = (s) -> System.out.println("Consumer "+s);
		consumer.accept("hai");
		
		Consumer<String> consumer1 = System.out::println;
		consumer1.accept("jay");
		
		BiFunction<Integer, Integer, Integer> add = DemoClass :: add;
		System.out.println("addition:"+add.apply(5, 8));
		
		//if the method is not static
		/*
		DemoClass dc = new DemoClass();
		BiFunction<Integer, Integer, Integer> add = dc :: add;
		System.out.println("addition:"+add.apply(5, 8));
		*/
		IntSupplier s = () -> new String("kldjf").length();
		System.out.println("String length using supplier:"+s.getAsInt());
		
		Function<String, Integer> strlen = (s1) -> s1.length();
		System.out.println("String length using function:"+strlen.apply("string"));
		
		Function<String, Integer> mr1 = String :: length;
		System.out.println("function str length : "+mr1.apply("smith"));
	
		Function<String, String> mr2 = String :: toUpperCase;
		System.out.println("Uppercase:"+mr2.apply("smith"));
		
		//Function<Integer, Integer> add = 
		
		MyInterface mi = (x, y, z) -> {//(int a, int b, int c)
			int max = z;
			if(x > y && x > z)
				max = x;
			else if(y > z)
				max = y;
			return max;
		};
		System.out.println(mi.findMax(9, 6, 7));
		
		MyInterface mi1 = (x, y, z) -> (x > y && x > z)?x:(y > z ? y : z);
		System.out.println(mi1.findMax(9, 6, 7));
	
		TestDisplay td = () -> System.out.println("Hello I'm void method!");
		td.display();
		
		TestDisplay td1 = () -> {System.out.println("Hello I'm void method!");
		System.out.println("Thanks for your attention");
		};
		td1.display();
	}
}

@FunctionalInterface //when another method in functional interface is written, compiler error is thrown
interface TestDisplay{
	void display();
}
interface MyInterface{
	int findMax(int a, int b, int c);
}
interface TestInter{
	boolean test(int a);
}

interface MaxFinder{
	int findMax(int a, int b);
}
class DemoClass{
	public static Integer add(int a, int b) {
		return a+b;
	}
}

/*
class MaxFinderImpl implements MaxFinder{
	@Override
	public int findMax(int a, int b) {		
		return a>b?a:b;
	}
}*/