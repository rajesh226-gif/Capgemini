package files.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import jdbc.Employee;

public class StreamDemo {
	public static void main(String[] args) {
		Stream<Integer> stream = Stream.of(1,2,3,4,5,6,7,8,9,10);
		//Integer i = stream.reduce((a,b)->a+b).get();
		//System.out.println(i);
		stream.sorted().forEach(System.out::println);
		String[] str = {"A","B","C"};
		Stream<String> strStream = Arrays.stream(str);
		List<String> strlist = new ArrayList<>();
		strlist.add("red");
		strlist.add("green");
		strlist.add("brown");
		strlist.add("purple");
		
		Stream<String> cstream = strlist.stream();
		//cstream.forEach(System.out::println);
		//incorrect cstream.map(s->s.toUpperCase());
		//cstream.map(String::toUpperCase).forEach(System.out::println);
		//cstream.map(s->s.length()).forEach(System.out::println);
		//cstream.filter(s->s.length()>4?true:false).forEach(System.out::println);
		
		//System.out.println(cstream.filter(s->s.length()>4?true:false).collect(Collectors.toList()));
		List<String> filteredList = cstream.filter(s->s.length()>4?true:false).collect(Collectors.toList());
		filteredList.stream().forEach(System.out::println);
		
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(101,"raj",87888));
		empList.add(new Employee(202,"amit",8787));
		
		Stream<Employee> empStream = empList.stream();
		//empStream.forEach(System.out::println);
		//empStream.filter(e->e.getSal()>10000).forEach(System.out::println);
		//empStream.sorted((e1, e2) -> e1.geteName().compareTo(e2.geteName())).forEach(System.out::println);;
		//empStream.sorted(Comparator.comparingInt(Employee::getSalary)).forEach(System.out::println);
	}
}
