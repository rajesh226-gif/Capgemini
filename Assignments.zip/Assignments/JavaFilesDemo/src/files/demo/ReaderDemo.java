package files.demo;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ReaderDemo {
	public static void main(String[] args) throws Exception {
		FileReader fr = new FileReader("text2.txt");
		int a = fr.read();
		//character stream writes or reads 2 bytes at a time
		while(a != -1) {
			System.out.println((char)a);
			a = fr.read();
		}
		fr.close();
	}
}
