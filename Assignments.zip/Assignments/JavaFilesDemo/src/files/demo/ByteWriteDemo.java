package files.demo;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteWriteDemo {
	public static void main(String[] args)  {
		FileOutputStream fos = null;
		try{
			
			fos = new FileOutputStream("bytewritedemo.txt"); //true = append mode
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			DataOutputStream dos = new DataOutputStream(bos);//helps to write primitive data types
			
			/*int len = 0;
			Byte b[] = {23,34,89};
			while(len < b.length) {
				fos.write(b[len]);
				len++;
			
			}*/
			dos.writeChars("annasarp");
			//dos.writeDouble(78.45);
			dos.flush();
			dos.close();
			
			
		}
		catch(Exception e) {
			
		}
		finally {
			try {
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}

