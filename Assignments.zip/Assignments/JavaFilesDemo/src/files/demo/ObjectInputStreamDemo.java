package files.demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectInputStreamDemo {
	public static void main(String[] args) throws Exception {
		
		FileInputStream fis = new FileInputStream("stud.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Student s = (Student)ois.readObject();
		
		System.out.println(s.getStudentName());
		System.out.println(s.getRollNumber());
		
		/*
		Student s2 = (Student)ois.readObject();
		
		System.out.println(s2.getStudentName());
		System.out.println(s2.getRollNumber());
		*///throws ends of file exception because there's no second object
		
		ois.close();
	}
}
