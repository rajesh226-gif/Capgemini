package files.demo;

import java.io.FileWriter;
import java.io.IOException;

public class WriterDemo {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("text2.txt");
		fw.write(97);
		fw.write(98);
		fw.write(99);
		fw.close();
	}
}
