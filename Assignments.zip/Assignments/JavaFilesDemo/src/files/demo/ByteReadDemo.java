package files.demo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class ByteReadDemo {
	public static void main(String[] args) throws Exception  {
		
		FileInputStream fis = new FileInputStream("test.txt");
		BufferedInputStream bis = new BufferedInputStream(fis);
		DataInputStream dis = new DataInputStream(bis);
		int a = bis.read();
		/*while(a != -1) {
			System.out.println(a);
			a = dis.readInt();
		}
		dis.close();
		*/while(a != -1) {
			System.out.println(a);
			a = bis.read();
		}
		dis.close();
	}
}
