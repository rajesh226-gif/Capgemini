package logpack;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

public class LogDemo {//getting the class name dynamically
	static Logger log = Logger.getLogger("logdemo");
	public static void main(String[] args) {
		//statement used to 
		//DOMConfigurator.configure("log4j.xml");
		PropertyConfigurator.configure("Lo4j.properties");
		new LogDemo().withdraw();
	}
	
	public void withdraw() {
		log.info("going to withdraw");
		log.debug("debug");
		log.warn("warn");
		System.out.println(log.getName());
		System.out.println(log.getLevel());
		System.out.println("Inside withdraw");
	}
	public void deposit() {
		System.out.println("Inside deposit");
	}
}
