package threadpack;

public class ThreadDemo {
	public static void main(String[] args) throws Exception {
		AudioThread at = new AudioThread();
		Thread th = new Thread(at);
		//Thread th = new Thread(at,"audio"); specifying thread name 
		//at.start();
		th.start();
		//th.setPriority(8);//no guarantee of getting according to priority
		th.setPriority(th.MAX_PRIORITY);
		th.join(); //after the completion of 2nd thread, main thread restarts
		for(int i = 0; i < 5; i++) {
			System.out.println("main "+i);
			th.sleep(5000);
		System.out.println("main thread finished");
	}
	}
}
	class AudioThread implements Runnable{

		@Override
		public void run() {
			// TODO Auto-generated method stub

			for(int i = 0; i < 5; i++) {
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("audio thread "+i);
			}System.out.println("audio thread finished");
		}
	}
	
/*class AudioThread extends Thread{
public void run() {
	for(int i = 0; i < 5; i++)
		System.out.println("audio thread "+i);
	System.out.println("audio thread finished");
	
}
}*/