package testing;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class CalculatorTest {
	static Calculator c;
	@BeforeClass
	public static void preInit() {
		int tdata1 = 10;
		int tdata2 = 5;
		c = new Calculator(tdata1,tdata2);
		System.out.println("Before class");
	}
	
	@Test
	public void testAdd() {
		int expectedResult = 15;
		//Calculator c = new Calculator(3,2);
		int actualResult = c.add();
		Assert.assertEquals(expectedResult, actualResult);
	}
	@Test
	public void testDivide1() {
		int expectedResult = 2;
		//Calculator c = new Calculator(10,5);
		int actualResult = c.divide();
		Assert.assertEquals(expectedResult, actualResult);
	}
	
	@Test(expected = ArithmeticException.class)//fail method also can be used in place of expected
	public void testDivide2() {
		Calculator c2 = new Calculator(10,0);
		int actualResult = c2.divide();
		
	}
	@Before
	public void testBefore() {
		System.out.println("Before");
	}
	@After
	public void testAfter() {
		System.out.println("After");
	}
	@AfterClass
	public static void testAfterClass() {
		System.out.println("After class");
	}
}
