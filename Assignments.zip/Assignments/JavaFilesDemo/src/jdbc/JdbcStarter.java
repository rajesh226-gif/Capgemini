package jdbc;

import java.sql.SQLException;

public class JdbcStarter {
	public static void main(String[] args) throws SQLException {
		Employee emp = new Employee();
		emp.setEmpNo(5003);
		emp.seteName("ajay");
		emp.setSal(457);
		emp.setDeptNo(16);
		//System.out.println(emp.toString());
		//new JdbcCrud().addEmployee(emp);
		//new JdbcCrud().deleteEmployee(emp);
		//new JdbcCrud().updateEmployee();
		//new JdbcCrud().fetchEmployee(5002);
		new JDBCCaseStudy().updateAccount();
	}
}
