package jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesDemo {

	public static void main(String[] args) throws Exception {
		Properties p = new Properties();
		/*FileInputStream in = new FileInputStream("myprop.properties");
		p.load(in);
		System.out.println(p.getProperty("username"));
		*/
		p.put("url", "jdbc");
		p.put("uname", "system");
		
		FileOutputStream fs = new FileOutputStream("app.properties");
		p.store(fs, "saved");
		fs.close();
		System.out.println("done");
		p.list(System.out);
	}
}
