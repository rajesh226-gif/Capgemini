package jdbc;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JdbcCrud {
	Connection con = null;
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	JdbcCrud(){
		Connection con = null;
		
		try {
			con = DriverManager.getConnection(url, "system", "Capgemini123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void addEmployee(Employee e) {
		//load the driver -- converts the java query to sql query
		//establish the connection
		//prepare the statement
		//execute the statement
		//process the result
		//class.forName(Employee.class)//used to bring any class into the memory, which is not required in the current version
		//drivertype,ipaddress,dbinstance
		
		String sql = "insert into employee10 values(?,?,?,?,?)";
		try {
			//Statement st = con.createStatement();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, e.getEmpNo());
			ps.setString(2, e.geteName());
			ps.setString(3, e.getJob());
			ps.setInt(4, e.getSal());
			ps.setInt(5, e.getDeptNo());
			int rows = ps.executeUpdate();
			System.out.println(rows+" inserted successfully");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		
		
		
	}
	
	public void fetchEmployee(int eid) {
		
		try {
			String sql = "select * from employee10 where empno = ?";
			//String sql = "select * from employee10 where empno = :eid"; :eid is a named parameter, another way to assign value to the variable
			con = DriverManager.getConnection(url, "system", "Capgemini123");
			//Statement st = con.createStatement();
			//Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, eid);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int eid1 = rs.getInt(1);
				String name = rs.getString(2);
				int sal = rs.getInt(4);
				int dept = rs.getInt(5);
				System.out.println(eid1 + " "+name+" "+sal+" "+dept);
				
			}
			//System.out.println(rows+" updated successfully");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void updateEmployee() {
		String sql = "update employee10 set deptno = 5 where deptno = 15";
		try {
			con = DriverManager.getConnection(url, "system", "Capgemini123");
			Statement st = con.createStatement();
			int rows = st.executeUpdate(sql);
			System.out.println(rows+" updated successfully");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void deleteEmployee(Employee e) {
		String sql = "delete from employee10 where deptno = "+e.getDeptNo();
		try {
			con = DriverManager.getConnection(url, "system", "Capgemini123");
			Statement st = con.createStatement();
			int rows = st.executeUpdate(sql);
			System.out.println(rows+" deleted successfully");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}
}
