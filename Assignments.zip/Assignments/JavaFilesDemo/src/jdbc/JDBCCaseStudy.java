package jdbc;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCCaseStudy {
	Connection con = null;
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	JDBCCaseStudy(){		
		try {
			con = DriverManager.getConnection(url, "system", "Capgemini123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void updateAccount() throws SQLException {
		String sql1 = "update account set balance = balance - 4000 where accountno = 1001";
		String sql2 = "update account set balance = balance + 4000 where accountno = 1002";
		try {
			//Statement st = con.createStatement();
			con.setAutoCommit(false);
			PreparedStatement ps = con.prepareStatement(sql1);
			PreparedStatement ps1 = con.prepareStatement(sql2);
			ps.executeUpdate();
			ps1.executeUpdate();
			con.commit();
			System.out.println("transfer success");
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			con.rollback();
			System.out.println("roll back");
		}
		finally {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
