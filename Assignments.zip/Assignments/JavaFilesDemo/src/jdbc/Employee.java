package jdbc;

import java.util.Date;

public class Employee {//employee10 in database
	Integer empNo;
	String eName;
	String job;
	Integer sal;
	Integer deptNo;
	
	public Employee(Integer empNo, String eName, Integer sal) {
		super();
		this.empNo = empNo;
		this.eName = eName;
		this.sal = sal;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Integer getSal() {
		return sal;
	}
	public void setSal(Integer sal) {
		this.sal = sal;
	}
	public Integer getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(Integer deptNo) {
		this.deptNo = deptNo;
	}
	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", eName=" + eName + ", job=" + job + ", sal=" + sal + ", deptNo=" + deptNo
				+ "]";
	}
	
	
}
