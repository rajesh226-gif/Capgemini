package com.dmart.shopping.user;

import java.util.ArrayList;
import java.util.Scanner;

import com.dmart.shopping.entity.Product;
import com.dmart.shopping.services.IProduct;
import com.dmart.shopping.services.ImplProduct;

public class ClientApp {
	public static void main(String[] args) {
		
		IProduct service = new ImplProduct();
		
		Scanner sc = new Scanner(System.in);
		String ans;
		int no;
		
		do {
			System.out.println("***** DMART Products Services *****");
			System.out.println("1. Add Product");
			System.out.println("2. Show All Products");
			System.out.println("3. Search Product by Id");
			System.out.println("Please enter your choice : ");
			no = sc.nextInt();
			switch(no) {
				case 1 : System.out.println("Enter details of product");
				         System.out.println("Enter id : ");
				         int id = sc.nextInt();
						 System.out.println("Enter name : ");
						 String name = sc.next();
						 System.out.println("Enter cost : ");
						 float cost = sc.nextFloat();
						 Product p = new Product(id, name, cost);
						 
						 ArrayList<Product> list = new ArrayList<>();
						 list = service.addProducts(p);
						 System.out.println(list);
						 break;
				case 2 : System.out.println("hello i'm 2");
						 break;
				case 3 : System.out.println("hello i'm 3");
				 		 break;
				default : System.out.println("Incorrect selection");
						  break;
			}
			System.out.println("Do you want to continue? yes/no");
			ans = sc.next();
		}while(ans.equals("yes") || ans.equals("Yes") || ans.equals("YES"));
	}
}
