package com.dmart.shopping.services;

import java.util.ArrayList;

import com.dmart.shopping.entity.Product;

public class ImplProduct implements IProduct {
	ArrayList<Product> myList;
	
	

	public ImplProduct() {
		myList = new ArrayList<Product>();
	}



	@Override
	public ArrayList<Product> addProducts(Product p) {
		myList.add(p);
		return myList;
	}



	

	

	
	
}
