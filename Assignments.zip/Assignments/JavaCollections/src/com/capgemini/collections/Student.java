package com.capgemini.collections;

public class Student implements Comparable{
	
	private int stuRoll;
	private String stuName;
	private float stuFee;
	
	public Student() {
		super();
	}

	public Student(int stuRoll, String stuName, float stuFee) {
		super();
		this.stuRoll = stuRoll;
		this.stuName = stuName;
		this.stuFee = stuFee;
	}
	
	public int getStuRoll() {
		return stuRoll;
	}

	public void setStuRoll(int stuRoll) {
		this.stuRoll = stuRoll;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public float getStuFee() {
		return stuFee;
	}

	public void setStuFee(float stuFee) {
		this.stuFee = stuFee;
	}
	
	

	@Override
	public String toString() {
		return "Student [stuRoll=" + stuRoll + ", stuName=" + stuName + ", stuFee=" + stuFee + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(stuFee);
		result = prime * result + ((stuName == null) ? 0 : stuName.hashCode());
		result = prime * result + stuRoll;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (Float.floatToIntBits(stuFee) != Float.floatToIntBits(other.stuFee))
			return false;
		if (stuName == null) {
			if (other.stuName != null)
				return false;
		} else if (!stuName.equals(other.stuName))
			return false;
		if (stuRoll != other.stuRoll)
			return false;
		return true;
	}
	/*Integer empId;
	public boolean equals(Object o){
		Student s = (Student)o;
		boolean result = false;
		if(this.id.equals(s.id))
			result = true;
		return result;
	}*/

	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		Student s = (Student) arg0;
		//if(this.stuRoll.eq == s.stuRoll)
			//return 0;
		return 0;
	}
}
