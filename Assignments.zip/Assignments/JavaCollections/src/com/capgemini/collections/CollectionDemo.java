package com.capgemini.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class CollectionDemo {
	public static void main(String[] args) {
		
		List<Student> mylist = new ArrayList();
		ArrayList<?> myList = new ArrayList<Integer>(); //-- not possible why?
		
		Student s1 = new Student(101,"Jay",30000.00f);
		Student s2 = new Student(102,"Vijay",30000.00f);
		Student s3 = new Student(103,"Sanjay",30000.00f);
		
		//Book b1 = new Book(1,"java","kathy S","Programming");
		//System.out.println(s3.toString());
		mylist.add(s1);
		mylist.add(s2);
		mylist.add(s3);
		//mylist.add(b1);
		
		//for(Object i : mylist)
		//	System.out.println(i);
		/*
		Iterator i = mylist.iterator();
		while(i.hasNext()) {
			//System.out.println(i.next());
		}*/
		Iterator i = mylist.iterator();

		System.out.println(mylist);
		mylist.removeAll(mylist);
		System.out.println(mylist);
		//Integer var = (Integer) i.next();
		
		// another way to create iterator of integer type
		
		// Iterator<Integer> i = mylist.iterator();
		/*
		 * Generic class example
		 * 
		 * class Box<T1, T2>{
		 * 
		 * 
		 * }
		 */
		ListIterator li = mylist.listIterator();
		/*li.hasnext();
		li.next();
		li.hasPrevious()
		li.remove();
		while(li.hasNext()) {
			Student stu = (student)li.next();
			if(stu)
				li.remove();
					
		}*/
		
	}
}
