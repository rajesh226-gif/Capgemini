package com.capgemini.collections;

import java.util.Comparator;

public class EmpIdComparator implements Comparator{

	@Override
	public int compare(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
