package com.capgemini.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class SetDemo {
	public static void main(String[] args) {
		HashSet<Student> hs = new HashSet<>();
		Student s1 = new Student();
		s1.setStuRoll(1);
		s1.setStuName("prasanna");
		
		Student s2 = new Student();
		s2.setStuRoll(1);
		s2.setStuName("prasanna");
		
		hs.add(s1);
		hs.add(s2);
		System.out.println(hs.size());
		
		
		
	}
	
}
