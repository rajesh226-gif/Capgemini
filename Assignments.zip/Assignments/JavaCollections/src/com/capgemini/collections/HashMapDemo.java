package com.capgemini.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapDemo {
	public static void main(String[] args) {
		
		TreeMap<Integer, String> tm = new TreeMap<>();
		//tm.put(arg0, arg1);
		
		HashMap<Integer, String> hm = new HashMap<>();
		
		hm.put(1, "Hello");
		hm.put(2, "Hai");
		
		Set<Integer> s1 = hm.keySet();
		
		System.out.println(s1);
		
		for(Integer i : s1) {
			
		}
		
		Set<Entry<Integer, String>> es = hm.entrySet();
		System.out.println(es);
		
		for(Entry<Integer, String> e : es) {
			System.out.println(e.getValue());
			System.out.println(e.getKey());
		}
		/*System.out.println(hm); //returns a map output: {1=Hello, 2=Hai}
		
		System.out.println(hm.put(3, "Vijay"));	//inserting a new element put returns null 	
		System.out.println(hm.put(1, "Jay"));   // inserting a value in existing key returns the previous value
		
		System.out.println(hm.keySet());
		System.out.println(hm.values());
		
		Set ks = hm.keySet();
		for(Object s : ks)
			System.out.println(hm.get(s)); // returns the values
			//System.out.println(s); // keys will be printed
		
		Collection c = hm.values();
		System.out.println(c);
		
		Iterator i = ks.iterator();
		//TODO
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		
		System.out.println(hm.entrySet()); // returns set of entries output : [1=Jay, 2=Hai, 3=Vijay]
		
		Set eset = hm.entrySet();
		for(Object o : eset) {
			Entry entry = (Entry)o;
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());*/
		}
	}

