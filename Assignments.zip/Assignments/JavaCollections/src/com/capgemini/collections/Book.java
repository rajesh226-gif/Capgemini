package com.capgemini.collections;

public class Book {
	private int bookId;
	private String bookTitle;
	private String bookAuthor;
	private String bookGener;
	
	public Book() {
		super();
	}

	public Book(int bookId, String bookTitle, String bookAuthor, String bookGener) {
		super();
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookAuthor = bookAuthor;
		this.bookGener = bookGener;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookGener() {
		return bookGener;
	}

	public void setBookGener(String bookGener) {
		this.bookGener = bookGener;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookTitle=" + bookTitle + ", bookAuthor=" + bookAuthor + ", bookGener="
				+ bookGener + "]";
	}
	
}
