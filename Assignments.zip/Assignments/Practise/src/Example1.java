class Parent{
	public void display() {
		System.out.println("A");
	}
}





public class Example1 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
