package com.capgemini.practice.staticdemo;

class Facebook{
	int id;
	int n = 0;
	static int likes = 0;
	Facebook(int id){
		this.id = id;
	}
	static void imgclick() {
		likes++;
		System.out.println("likes "+likes+"\n");
		
	}
	void show() {
		n++;
		System.out.println("User ID : "+id +"\t");
		System.out.println("n : " + n);
	}
	
}

public class TestFacebook {
	public static void main(String[] args) {
		Facebook user1 = new Facebook(101);
		user1.show();
		Facebook.imgclick();
		
		Facebook user2 = new Facebook(102);
		user2.show();
		Facebook.imgclick();
		
		Facebook user3 = new Facebook(103);
		user3.show();
		Facebook.imgclick();
	}
}
