package com.capgemini.practice.product;

public class Product {
	int bar_code;
	String product_Name;
	double product_cost;
	String product_descrip;
	
	public Product() {
		super();
		this.product_descrip = "santoor product";
	}

	public Product(int bar_code, String product_Name, double product_cost) {
		super();
		this.bar_code = bar_code;
		this.product_Name = product_Name;
		this.product_cost = product_cost;
		//this.product_descrip = "santoor product";
	}
	
	public double billAmount(int qty) {
		return product_cost * qty;
	}

	public int getBar_code() {
		return bar_code;
	}

	public void setBar_code(int bar_code) {
		this.bar_code = bar_code;
	}

	public String getProduct_Name() {
		return product_Name;
	}

	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}

	public double getProduct_cost() {
		return product_cost;
	}

	public void setProduct_cost(double product_cost) {
		this.product_cost = product_cost;
	}

	public String getProduct_descrip() {
		return product_descrip;
	}

	public void setProduct_descrip(String product_descrip) {
		this.product_descrip = product_descrip;
	}

	@Override
	public String toString() {
		return "Product [bar_code=" + bar_code + ", product_Name=" + product_Name + ", product_cost=" + product_cost
				+ ", product_descrip=" + product_descrip + "]";
	}	
}
