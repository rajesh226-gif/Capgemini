package com.capgemini.practice.comparable;

import java.util.Comparator;

public class ComparableDemo implements Comparator{
	int stuId;
	String stuName;
	
	public ComparableDemo() {
		super();
	}

	public ComparableDemo(int stuId, String stuName) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
	}

	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	@Override
	public int compare(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		
		return 0;
	}
	
	
	
}
