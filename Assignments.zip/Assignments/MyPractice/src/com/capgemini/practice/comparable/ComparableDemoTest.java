package com.capgemini.practice.comparable;

import java.util.TreeSet;

public class ComparableDemoTest {
	
	public static void main(String[] args) {
		StringBuffer s = new StringBuffer("123456789");
		System.out.println(s.delete(0, 3).delete(1, 3));
	}
}
