package com.capgemini.practice.product_user;

import java.util.Scanner;

import com.capgemini.practice.product.Product;

public class ProductUser {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Product p1 = new Product(123,"soap",89);
		System.out.println("Enter the quantity for soap: ");
		
		int qty = sc.nextInt();
		double cost = p1.billAmount(qty);
		
		System.out.println("Your bill Amount : " + cost);
				
		/*
		Product p2 = new Product();
		p2.setProduct_Name("oil");
		p2.setBar_code(12);
		p2.setProduct_cost(500);		
		System.out.println(p2.toString());
	
		Product p3 = new Product();
		p3.setBar_code(45);
		p3.setProduct_Name("rice");
		p3.setProduct_cost(900);
		
		System.out.println("Barcode : " + p3.getBar_code()+ "\nProct_Name : "+ p3.getProduct_Name() + "\ncost : "+ p3.getProduct_cost()+"\nProduct Description : "+p3.getProduct_descrip());
	*/
	
	}
}
