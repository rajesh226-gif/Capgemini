package com.capgemini.labbook.lab10;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeService10_2 {
	Connection con = null;
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	EmployeeService10_2(){
		
		try {
			con =  DriverManager.getConnection(url, "system", "Capgemini123");
			System.out.println("hello");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void addEmployee(Employee10_1 e) {
		try {
			String sql = "insert into employee10 values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, e.getEmpId());
			ps.setString(2, e.getEmpName());
			ps.setDouble(3, e.getEmpSal());
			ps.setString(4, e.getEmpDesig());
			ps.setString(5, new EmployeeService10_2().getInsuranceScheme(e.getEmpSal(), e.getEmpDesig()));
			ps.executeUpdate();
			System.out.println("employee added successfully");
	
		}
		catch(Exception e1) {
			System.out.println("exception");
		}
	}
	
	public boolean deleteEmployee(int id)	{
//	     code to delete a employee whose id is passed as parameter
		String sql = "delete from employee10 where empid = "+id;
		try {
			con = DriverManager.getConnection(url, "system", "Capgemini123");
			Statement st = con.createStatement();
			int rows = st.executeUpdate(sql);
			System.out.println(rows+" deleted successfully");
		}catch(Exception e) {
			System.out.println("Exception");
		}
		return true;
	}
	
	public List<Employee10_1> getAllEmployees(){
		List<Employee10_1> lst = new ArrayList<>();
		String sql = "select * from employee10";
		//String sql = "select * from employee10 where empno = :eid"; :eid is a named parameter, another way to assign value to the variable
		try{
			con = DriverManager.getConnection(url, "system", "Capgemini123");
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Employee10_1 e = new Employee10_1();
				e.setEmpId(rs.getInt(1));
				e.setEmpName(rs.getString(2));
				e.setEmpSal(rs.getInt(3));
				e.setEmpDesig(rs.getString(4));
				e.setEmpIScheme(rs.getString(5));
				lst.add(e);
			}
		}
		catch(Exception e) {
			
		}
		return lst;
	}
	public String getInsuranceScheme(double empSal, String empDesig) {
		// TODO Auto-generated method stub
		String res = "";
		if(empSal < 5000 && empDesig.equals("Clerk"))
			res = "No_Scheme";
		if(empSal > 5000 && empSal < 20000 && empDesig.equals("SystemAssociate")) 
			res = "Scheme_c";
		else if(empSal >= 20000 && empSal < 40000 && empDesig.equals("Programmer"))
			res = "Scheme_B";
		else if(empSal >= 40000 && empDesig.equals("Manager"))
			res = "Scheme_A";
		return res;
	}
}