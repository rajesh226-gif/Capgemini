package com.capgemini.labbook.lab10;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;


public class EmployeeTest10_3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int empId;
		String empName;
		double empSal;
		String empDesig;
		String ans = "";
		
		EmployeeService10_2 es = new EmployeeService10_2();
		Employee10_1 emp;
		do {
			
			System.out.println("Choose from below : \n1. Get all Employees\n2. Delete Employee\n3. Display all Employees");
			int choice = sc.nextInt();
			
			
			switch(choice) {
			
			case 1 : System.out.println("Enter the employee details\nEmployee Id : ");
				 	 empId = sc.nextInt();
				 	 System.out.println("Employee Name : ");
				 	 empName = sc.next();
				 	 System.out.println("Salary : ");
				 	 empSal = sc.nextDouble();
				 	 System.out.println("Employee Designation : ");
				 	 empDesig = sc.next();
				 	 emp = new Employee10_1(empId,empName,empSal,empDesig);			
					 es.addEmployee(emp);
					 
					 break;
			case 2 : System.out.println("Enter employee Id");
					 empId= sc.nextInt();
					 es.deleteEmployee(empId);
					 //System.out.println(emp);
					 break;
			case 3 : List<Employee10_1> lst = es.getAllEmployees();
					 for(Employee10_1 e : lst)
						 System.out.println(e);
					 break;
			/*1case 4 : es.deleteEmployee(emp.getEmpId());
					 HashMap hs1 = new HashMap();
					 hs1 = es.getAllEmployees();
					 System.out.println(hs1);
					 break;
			case 5 : System.out.println("Enter the scheme : ");
					 String sch = sc.next();
					 HashMap hs2 = new HashMap();
					 hs2 = es.getEmpsByScheme(sch);
					 System.out.println(hs2);
					 break;
			*/
			default : System.out.println("Incorrect selection");
					  break;
		}
		System.out.println("Do you want to continue? yes/no");
		ans = sc.next();
		}while(ans.equals("yes") || ans.equals("Yes") || ans.equals("YES"));
	}
}
