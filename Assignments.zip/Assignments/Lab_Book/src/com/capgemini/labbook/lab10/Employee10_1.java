package com.capgemini.labbook.lab10;

public class Employee10_1 {
	private int empId;
	private String empName;
	private double empSal;
	private String empDesig; 
	private String empIScheme;
	
	public Employee10_1() {
		super();
	}
	
	
	public Employee10_1(int empId, String empName, double empSal, String empDesig) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesig = empDesig;
	}


	public Employee10_1(int empId, String empName, double empSal, String empDesig, String empIScheme) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesig = empDesig;
		this.empIScheme = empIScheme;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesig() {
		return empDesig;
	}

	public void setEmpDesig(String empDesig) {
		this.empDesig = empDesig;
	}

	public String getEmpIScheme() {
		return empIScheme;
	}

	public void setEmpIScheme(String empIScheme) {
		this.empIScheme = empIScheme;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDesig=" + empDesig
				+ ", empIScheme=" + empIScheme + "]";
	}

}
