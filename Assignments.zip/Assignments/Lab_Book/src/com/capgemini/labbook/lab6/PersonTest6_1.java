package com.capgemini.labbook.lab6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class PersonTest6_1 {
	
	public static void main(String[] args) throws Myexcep, IOException {
		
		String fName;
		String lName;
		String g;
		String phono;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.println("user Details\nFirstName : ");
		fName = br.readLine();
		System.out.println("LastName : ");
		lName = br.readLine();
		System.out.println("Gender : ");
		g = br.readLine();
		System.out.println("phone number : ");
		phono = br.readLine();
		if(fName.equals("") || lName.equals("")) {
			throw new Myexcep();
		}
		Person6_1 p = new Person6_1(fName,lName,Gender.valueOf(g),phono);
		//p.print();
		p.printDetails();
	}
	
}
class Myexcep extends Exception{
	public String getMessage() {
		return "First Name and Last Name should atleast be of length 1";
		
	}
}
