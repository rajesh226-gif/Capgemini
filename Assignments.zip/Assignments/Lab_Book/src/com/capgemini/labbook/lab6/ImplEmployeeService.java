package com.capgemini.labbook.lab6;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.capgemini.labbook.lab5.eis.bean.Employee;


public class ImplEmployeeService implements IEmployeeService{
	
	HashMap<String,Employee> list = new HashMap<String,Employee>();  
	
	public void addEmployee(Employee emp)	{
			//code to add employee
		IEmployeeService imples = new ImplEmployeeService();
		
		double empSal = emp.getEmpSal();
		String empDesig = emp.getEmpDesig();
		String empIScheme = imples.getInsuranceScheme(empSal, empDesig);
		emp.setEmpIScheme(empIScheme);
		list.put(""+emp.getEmpId(), emp);
	}
	public boolean deleteEmployee(int id)	{
//	     code to delete a employee whose id is passed as parameter
		list.remove(""+id);
		return true;
	}

	
	@Override
	public String getInsuranceScheme(double empSal, String empDesig) {
		// TODO Auto-generated method stub
		String res = "";
		if(empSal < 5000 && empDesig.equals("Clerk"))
			res = "No_Scheme";
		if(empSal > 5000 && empSal < 20000 && empDesig.equals("SystemAssociate")) 
			res = "Scheme_c";
		else if(empSal >= 20000 && empSal < 40000 && empDesig.equals("Programmer"))
			res = "Scheme_B";
		else if(empSal >= 40000 && empDesig.equals("Manager"))
			res = "Scheme_A";
		return res;
	}

	@Override
	public Employee getDetails(Employee emp) {
		// TODO Auto-generated method stub
		IEmployeeService imples = new ImplEmployeeService();
		
		double empSal = emp.getEmpSal();
		String empDesig = emp.getEmpDesig();
		String empIScheme = imples.getInsuranceScheme(empSal, empDesig);
		emp.setEmpIScheme(empIScheme);
		return emp;
	}
	@Override
	public HashMap getAllEmployees() {
		// TODO Auto-generated method stub
		return list;
	}
	@Override
	public TreeSet<Employee> getEmpBySal() {
		// TODO Auto-generated method stub
		TreeSet<Employee> lst = new TreeSet<>();
		for(Employee l : list.values())
			lst.add(l);
		return lst;
	}
	
	@Override
	public HashMap getEmpsByScheme(String sch) {
		// TODO Auto-generated method stub
		HashMap res = new HashMap();
		Set<Entry<String, Employee>> es = list.entrySet();
		for(Entry<String, Employee> e : es) {
			if(e.getValue().getEmpIScheme().equals(sch))
				res.put(e.getKey(), e.getValue());
		}
		return res;
	}

	public void writeToFile() throws Exception {
		System.out.println("writing to file");
		FileOutputStream fos = new FileOutputStream("employee.txt");
		ObjectOutputStream os = new ObjectOutputStream(fos);
		Collection<Employee> lst = list.values();
		for(Employee e : lst) {
			os.writeObject(e);
		}

		FileInputStream fis = new FileInputStream("employee.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		for(int i = 0; i < lst.size(); i++) {
			System.out.println(ois.readObject());
		}
	}
}
