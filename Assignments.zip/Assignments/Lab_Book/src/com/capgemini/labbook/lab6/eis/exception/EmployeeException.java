package com.capgemini.labbook.lab6.eis.exception;



public class EmployeeException extends Exception{
	public String getMessage() {
		return "salary should be greater than 3000";
	}
}