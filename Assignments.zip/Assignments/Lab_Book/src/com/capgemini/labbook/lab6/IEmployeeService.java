package com.capgemini.labbook.lab6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.TreeSet;

import com.capgemini.labbook.lab5.eis.bean.Employee;

public interface IEmployeeService {
	
	public abstract void addEmployee(Employee emp);
	public abstract boolean deleteEmployee(int id);
	public abstract String getInsuranceScheme(double empSal, String empDesig);
	public abstract Employee getDetails(Employee emp);
	public abstract HashMap getAllEmployees();
	public abstract TreeSet<Employee> getEmpBySal();
	public abstract HashMap getEmpsByScheme(String sch);
	public abstract void writeToFile() throws Exception;
}
