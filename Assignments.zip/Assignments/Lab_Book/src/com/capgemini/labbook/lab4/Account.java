package com.capgemini.labbook.lab4;

abstract public class Account {
	long accNum;
	double balance;
	Person accHolder;
	static int count = 1;
	public Account() {
		super();
		accNum = count;
		count++;
	}
	public Account(double balance, Person accHolder) {
		super();
		accNum = count;
		count++;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public void deposit(double d) {
		balance += d;
	}
	abstract public void withdraw(double d);
	/*public void withdraw(double d) {
		balance -= d;
	}*/
	public double getBalance() {
	
		return 0.0;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		System.out.println(balance);
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
	}
	
	
}
