package com.capgemini.labbook.lab4;

public class SavingsAccount extends Account {
	final public double minBal = 1000;
	public SavingsAccount(double sal,Person p) {
		// TODO Auto-generated constructor stub
		super(sal,p);
	}
	public void withdraw(double d) {
		//System.out.println(balance);
		if(balance - d >= minBal)
			balance -= d;
		else
			System.out.println("You cannot withdraw");
	}
	
	public static void main(String[] args) {
		System.out.println("Current Accounts status");
		Person p1 = new Person("Smith",56);
		Account a1 = new SavingsAccount(2000,p1);
		System.out.println(a1);
		System.out.println("Status after withdraw of 1000 in Kathy's account");
		//System.out.println(a1);
		a1.withdraw(3000);
		System.out.println(a1.toString());
	}
	
}
