package com.capgemini.labbook.lab7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Program7_2 {
	public static void main(String[] args) {
		ArrayList<String> arr = new ArrayList<>();
		arr.add("grapes");
		arr.add("pineapple");
		arr.add("mango");
		arr.add("apples");
		arr.add("banana");
		Collections.sort(arr);
		for(String i : arr)
			System.out.println(i);
	}
}
