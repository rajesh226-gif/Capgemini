package com.capgemini.labbook.lab13;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileProgram {
	public static void main(String[] args) throws Exception {
		FileOutputStream fos = new FileOutputStream("target.txt"); //true = append mode
		FileInputStream fis = new FileInputStream("source.txt");
		CopyDataThread at = new CopyDataThread(fos,fis);
		Thread th = new Thread(at);
		th.start();
	}
}
