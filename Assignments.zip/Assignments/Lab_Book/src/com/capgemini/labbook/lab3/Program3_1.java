package com.capgemini.labbook.lab3;

import java.util.HashSet;
import java.util.Set;

public class Program3_1 {
	public String addStringToSelf(String str) {
		return str+str;
	}
	public String replaceOddPos(String str) {
		for(int i = 0; i < str.length(); i++) {
			if(i % 2 == 0)
				str = str.substring(0,i)+"#"+str.substring(i+1,str.length());
		}
		return str;
	}
	public String removeDuplicates(String str) {
		int[] arr = new int[26];
		String res = "";
		for(int i = 0; i < str.length(); i++) {
			arr[str.charAt(i)-'a']++;
		}
		for(int i = 0; i < 26; i++) {
			if(arr[i] != 0)
				res += (char)('a'+i);
		}
		return res;
	}
	public String removeDuplicates1(String str) {
		Set<String> s = new HashSet<String>();
		for(int i = 0; i < str.length(); i++) {
			if(!s.contains(str.charAt(i)))
				s.add(""+str.charAt(i));
		}
		return s.toString();
	}
	public String changeOddChar(String str) {
		for(int i = 0; i < str.length(); i++) {
			if(i % 2 == 0)
				str = str.substring(0,i)+(char)(str.charAt(i)-32)+str.substring(i+1,str.length());
		}
		return str;
	}
}

