package com.capgemini.labbook.lab3;

import java.util.Scanner;

public class Program3_2Test {
	public static void main(String[] args) {
		Program3_2 p = new Program3_2();
		System.out.println("Enter a string : ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		if(p.checkstring(s))
			System.out.println("The string entered is a positive string");
		else
			System.out.println("The string entered is a negative string");
	}
}
