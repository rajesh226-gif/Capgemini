package com.capgemini.labbook.lab3;

import java.util.Scanner;

public class Program3_5Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter product purchase date in dd/MM/yyyy format:");
		String date1  = sc.nextLine();
		
		System.out.println("Enter the warrantee period(months and years) in MM/YYYY format");
		String date2 = "01/"+ sc.nextLine();
		
		Program3_5 p = new Program3_5();
		String str = p.printExpiryDate(date1,date2);
		String[] res = str.split("/");
		String ans = ""+Integer.parseInt(date1.substring(3,5))+Integer.parseInt(res[0]);
		System.out.println(ans);
		//System.out.println("Days : "+res[0]);
		//System.out.println("Months : "+res[1]);
		//System.out.println("Years : "+res[2]);
	}
}
