package com.capgemini.labbook.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Program3_4 {
	public String printDuration(String date1, String date2) {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		//Almost every class in java.time package provides parse() method to parse the date or time
		LocalDate dt1 = LocalDate.parse(date1,formatter);
		LocalDate dt2 = LocalDate.parse(date2,formatter);
		//LocalDate end = LocalDate.now();
		
		Period period = dt1.until(dt2);
		return period.getDays()+"/"+period.getMonths()+"/"+period.getYears();		
	}
}

