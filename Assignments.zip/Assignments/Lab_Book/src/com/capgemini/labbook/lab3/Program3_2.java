package com.capgemini.labbook.lab3;

public class Program3_2 {
	public boolean checkstring(String str) {
		for(int i = 0; i < str.length()-1; i++) {
			if(str.charAt(i) > str.charAt(i+1))
				return false;
		}
		return true;
	}
}
