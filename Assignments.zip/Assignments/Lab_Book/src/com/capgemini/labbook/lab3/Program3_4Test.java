package com.capgemini.labbook.lab3;

import java.util.Scanner;

public class Program3_4Test {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter two dates in dd/MM/yyyy format:");
		
		String date1  = sc.nextLine();
		String date2 = sc.nextLine();
		
		Program3_4 p = new Program3_4();
		String str = p.printDuration(date1,date2);
		String[] res = str.split("/");
		
		System.out.println("Days : "+res[0]);
		System.out.println("Months : "+res[1]);
		System.out.println("Years : "+res[2]);
	}
}
