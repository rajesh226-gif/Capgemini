package com.capgemini.labbook.lab9;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class Test1 {
	static Date d;
	@BeforeClass
	public static void preInit() {	
		d = new Date(29,10,1997);
	}
	
	@Test
	public void testGetIntDay() {
		Assert.assertEquals(29, d.getIntDay());
	}
	@Test
	public void testGetMonthDay() {
		Assert.assertEquals(10, d.getIntMonth());
	}
	@Test
	public void testGetYearDay() {
		Assert.assertEquals(1997, d.getIntYear());
	}
	@Test
	public void testToString() {
		String str = "Date [intDay=" + d.getIntDay() + ", intMonth=" + d.getIntMonth()+ ", intYear=" + d.getIntYear() + "]";
		Assert.assertEquals(str, d.toString());
	}
	
}
