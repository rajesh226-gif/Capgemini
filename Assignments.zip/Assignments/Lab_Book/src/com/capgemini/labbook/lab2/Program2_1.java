package com.capgemini.labbook.lab2;

public class Program2_1 {
	public static void main(String[] args) {
		System.out.println("Person Details :\n__________________\n\nFirst Name : Divya\nLast Name : Bharathi\nGender : F\nAge 20\nWeight : 85.5");
	}
}
