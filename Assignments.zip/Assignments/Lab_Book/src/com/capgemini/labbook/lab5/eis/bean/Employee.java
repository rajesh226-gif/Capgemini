package com.capgemini.labbook.lab5.eis.bean;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

public class Employee implements Comparable,Serializable{
	private int empId;
	private String empName;
	private double empSal;
	private String empDesig; 
	private String empIScheme;
	
	public Employee() {
		super();
	}
	
	

	public Employee(int empId, String empName, double empSal, String empDesig, String empIScheme) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesig = empDesig;
		this.empIScheme = empIScheme;
	}

	

	public Employee(int empId, String empName, double empSal, String empDesig) {
		// TODO Auto-generated constructor stub
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesig = empDesig;
	}



	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesig() {
		return empDesig;
	}

	public void setEmpDesig(String empDesig) {
		this.empDesig = empDesig;
	}

	public String getEmpIScheme() {
		return empIScheme;
	}

	public void setEmpIScheme(String empIScheme) {
		this.empIScheme = empIScheme;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDesig=" + empDesig
				+ ", empIScheme=" + empIScheme + "]";
	}



	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Employee e = (Employee)o;
		if(this.empSal == e.empSal)
			return 0;
		else if(this.empSal > e.empSal)
			return 1;
		else
			return -1;
	}
	
}
