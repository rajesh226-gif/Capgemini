package com.capgemini.basics.demos;

import java.util.Scanner;

public class Conditional_Operator {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b,c,d;
		System.out.println("enter a,b and c values:");
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.nextInt();
		d = (a > b) ? ((a > c) ? a  : c) : ((b > c) ? b : c);
		System.out.println("greater number is :"+d);
	}
}
