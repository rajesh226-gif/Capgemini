package com.capgemini.basics.demos;

import java.util.Scanner;

public class TestMaths {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Maths m = new Maths();
		int x, y, res;
		System.out.println("Enter x and y for addition");
		x = sc.nextInt();
		y = sc.nextInt();

		int sum = m.sum(x, y);
		int sub = m.sub(x, y);
		System.out.println("addition : "+sum);
		System.out.println("subtraction : "+ sub);
	}
}
