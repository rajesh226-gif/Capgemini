package com.capgemini.basics.demos;

import java.util.Scanner;

public class Arrays {
	public static void main(String[] args) {
		int marks[] = new int[5];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter an array of size 5 :");
		for(int i = 0; i < 5; i++) {
			marks[i] = sc.nextInt();
		}
		int sum = 0;
		for(int i = 0; i < 5; i++) {
			sum += marks[i];
		}
		System.out.println(sum/5);
		sc.close();
	}
}
