package com.capgemini.basics.inheritance;

public class SalesPerson extends Person{
	double commision;
	
	public SalesPerson(int id, String name, double commision) {
		super(id, name);
		this.commision = commision;
	}
	public double getCommision() {
		return commision;
	}

	public void setCommision(double commision) {
		this.commision = commision;
	}

	@Override
	public String toString() {
		return "SalesPerson [commision=" + commision + ", id=" + id + ", name=" + name + "]";
	}
	
	public void calc() {
		System.out.println("Sales Person Child class");
	}
	
	
}
