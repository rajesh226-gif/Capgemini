package com.capgemini.basics.inheritance;

public abstract class Person {
	public abstract void calc();
	int id;
	String name;
	public Person() {
		super();
	}
	
	public void show() {
		System.out.println("parent class - abstract class can also have its own methods also");
	}
	public Person(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + "]";
	}
	
	
}
