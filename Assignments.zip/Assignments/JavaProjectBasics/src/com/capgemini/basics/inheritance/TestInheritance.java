package com.capgemini.basics.inheritance;

public class TestInheritance {
	public static void main(String[] args) {
		//Person p1 = new Person(111,"jay");
		//System.out.println(p1);
		//p1.calc();
		
		Person e1 = new Emp(112,"vijay",5000.00f);
		System.out.println(e1);
		e1.calc();
		
		SalesPerson sp = new SalesPerson(112,"vijay",5000);
		System.out.println(sp);
		sp.calc();
		sp.show();
	}
}
