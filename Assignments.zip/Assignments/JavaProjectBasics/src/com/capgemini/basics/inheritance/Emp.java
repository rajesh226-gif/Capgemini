package com.capgemini.basics.inheritance;

public class Emp extends Person {
	
	double basicSal;
	
	public Emp(int id, String name, double basicSal) {
		super(id, name);
		this.basicSal = basicSal;
	}

	@Override
	public String toString() {
		return "Emp [basicSal=" + basicSal + ", id=" + id + ", name=" + name + "]";
	}
	
	public void calc() {
		System.out.println("Child class");
	}
	
	
	
}
