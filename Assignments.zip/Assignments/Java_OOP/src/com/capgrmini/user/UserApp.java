package com.capgrmini.user;

import com.capgemini.entity.Student;

public class UserApp {
	public static void main(String[] args) {
		
		Student s1 = new Student();
		s1.setStuId(101);
		s1.setStuName("Prasanna");
		s1.setSal(700);
		s1.setM1(968);
		s1.setM2(945);
		s1.setM3(617);
		System.out.println(s1.toString());
		
		Student s2 = new Student(101,"jay",700,91,98,97);
		/*s1.setStuId(101);
		s1.setStuName("Jay");
		s1.setSal(5000.00);*/
		
		System.out.println("total marks of "+s2.getStuName()+" is : " + s2.findTotalmarks());
		
		
		
	}
}
