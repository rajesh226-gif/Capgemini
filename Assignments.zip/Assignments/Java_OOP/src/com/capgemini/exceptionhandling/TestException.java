package com.capgemini.exceptionhandling;

import java.util.Scanner;

public class TestException {
	public static void main(String[] args) throws MyExcep {
		String empName;
		double basicSal;
		double travAll = 3000;
		System.out.println("Enter employee name and basic salary : ");
		Scanner sc = new Scanner(System.in);
		empName = sc.next();
		basicSal = sc.nextDouble();
		double grossSal = findGrossSal(empName, basicSal, travAll);
		System.out.println(grossSal);
	}
	public static double findGrossSal(String empName, double basicSal, double travAll) throws MyExcep {
		
		if(basicSal < 10000)
			throw new MyExcep();
		return basicSal + travAll - (basicSal/10);
	}
}

class MyExcep extends Exception{
	public String getMessage() {
		return "Employee can't have basic Salary < 10000";
	}
}