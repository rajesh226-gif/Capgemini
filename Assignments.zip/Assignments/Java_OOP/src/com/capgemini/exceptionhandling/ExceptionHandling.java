package com.capgemini.exceptionhandling;

//user defined exception
class NumException extends Exception{
	public String getMessage() {
		return "Plese check n2 has zero value";
	}
}

public class ExceptionHandling  {
	public static void main(String[] args) throws NumException {
		int n1, n2, result;
		n1 = 100;
		n2 = 0;
		result = calDiv(n1,n2);
		System.out.println(result);
	}
	public static int calDiv(int num1, int num2) throws NumException {
		if(num2 == 0)
			throw new NumException();
		else
			return num1/num2;
	}
}
