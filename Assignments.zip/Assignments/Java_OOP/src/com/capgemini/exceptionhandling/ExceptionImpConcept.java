package com.capgemini.exceptionhandling;
/*
 * If super class method does not declare any exception, 
 * then sub class overriden method cannot declare 
 * checked exception but it can declare unchecked exceptions.
 */

class SuperClass{
	
	//super class does'nt declare any exception
	void method() {
		System.out.println("SuperClass");
	}
}

class SubClass extends SuperClass{
	void method() throws ArithmeticException {//unchecked exp checked exception -- like throws IOException should not be written
		System.out.println("SubClass");
	}
}
public class ExceptionImpConcept {
	public static void main(String[] args) {
		SubClass s = new SubClass();
		s.method();
	}
}
