package com.capgemini.exceptionhandling;
/*
 * If super class method throws an exception,
 * then subclass overriden method can throw the same exception or no exception, or subclass
 * but must not throw parent exception of the exception thrown by super class method
 */
class SuperClass1{
	//super class declares an exception
	void method() throws RuntimeException{
		System.out.println("SuperClass");
	}
}
class SubClass1 extends SuperClass1{
	//subclass declaring an exception which are not a child exception of runtimeexception  
	void method() // throws ArithmeticException 
	{
		System.out.println("SubClass");
	}
}
public class ExceptionImpConcept2 {
	public static void main(String[] args) {
		SuperClass1 s = new SubClass1();
		s.method();
	}
}
