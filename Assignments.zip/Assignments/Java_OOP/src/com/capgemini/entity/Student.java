package com.capgemini.entity;

public class Student {
	
	public int stuId;
	public String stuName;
	public double sal;
	public int m1;
	public int m2;
	public int m3;
	
	public int findTotalmarks() {
		return m1+m2+m3;
	}
	public int getM1() {
		return m1;
	}

	public void setM1(int m1) {
		this.m1 = m1;
	}

	public int getM2() {
		return m2;
	}

	public void setM2(int m2) {
		this.m2 = m2;
	}

	public int getM3() {
		return m3;
	}

	public void setM3(int m3) {
		this.m3 = m3;
	}

	public Student(int stuId, String stuName, double sal) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.sal = sal;
	}

	public Student(int stuId, String stuName, double sal, int m1, int m2, int m3) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.sal = sal;
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public int getStuId() {
		return stuId;
		
		
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuName=" + stuName + ", sal=" + sal + ", m1=" + m1 + ", m2=" + m2
				+ ", m3=" + m3 + "]";
	}

		
}
