package com.capgemini.interfaces;

public class PermEmpImpl implements IPerson{

	int empId;
	double basicSal;
	
	public PermEmpImpl() {
		super();
	}

	public PermEmpImpl(int empId, double basicSal) {
		super();
		this.empId = empId;
		this.basicSal = basicSal;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public double getBasicSal() {
		return basicSal;
	}

	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}

	@Override
	public void calc() {
		// TODO Auto-generated method stub
		double tSal = basicSal + 1000;
		System.out.println("PermEmployee Total sal\t "+tSal);
	}

	@Override
	public String toString() {
		return "PermEmpImpl [empId=" + empId + ", basicSal=" + basicSal + "]";
	}

	
	
}
