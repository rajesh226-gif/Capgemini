package com.capgemini.interfaces;

public interface IPerson {
	public abstract void calc();
}
