package com.capgemini.interfaces;

public class TempEmpImpl implements IPerson{
	
	int tempId;
	double salperDay;
	int noDays;
	
	public TempEmpImpl() {
		super();
	}

	public TempEmpImpl(int tempId, double salperDay, int noDays) {
		super();
		this.tempId = tempId;
		this.salperDay = salperDay;
		this.noDays = noDays;
	}

	public int getTempId() {
		return tempId;
	}

	public void setTempId(int tempId) {
		this.tempId = tempId;
	}

	public double getSalperDay() {
		return salperDay;
	}

	public void setSalperDay(double salperDay) {
		this.salperDay = salperDay;
	}

	public int getNoDays() {
		return noDays;
	}

	public void setNoDays(int noDays) {
		this.noDays = noDays;
	}

	@Override
	public void calc() {
		// TODO Auto-generated method stub
		double tSal = salperDay * noDays;
		System.out.println("Temp Employee total sal\t" +  tSal);
	}

	@Override
	public String toString() {
		return "TempEmpImpl [tempId=" + tempId + ", salperDay=" + salperDay + ", noDays=" + noDays + "]";
	}

}
