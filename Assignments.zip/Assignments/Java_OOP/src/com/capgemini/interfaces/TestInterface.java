package com.capgemini.interfaces;

import java.util.Scanner;

public class TestInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the permanent emp id and basic salary:");
		int pempId = sc.nextInt();
		double sal = sc.nextDouble();
		PermEmpImpl pemp = new PermEmpImpl();
		pemp.setEmpId(pempId);
		pemp.setBasicSal(sal);
		pemp.calc();
		
		TempEmpImpl temp = new TempEmpImpl();
		temp.setTempId(102);
		temp.setNoDays(5);
		temp.setSalperDay(700);
		temp.calc();
		
		IPerson p;
		
		p = pemp;
		p.calc();
		
		p = temp;
		p.calc();
		
		IPerson p1 = new PermEmpImpl(pempId,sal);
		p1.calc();
		
		IPerson p2 = new TempEmpImpl(102,5,700);
		p2.calc();
	}
}
