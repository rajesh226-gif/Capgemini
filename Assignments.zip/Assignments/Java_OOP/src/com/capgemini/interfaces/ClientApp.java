package com.capgemini.interfaces;

public class ClientApp {
	public static void main(String[] args) {
		PermEmpImpl pemp = new PermEmpImpl();
		pemp.calc();
		
		TempEmpImpl temp = new TempEmpImpl();
		temp.calc();
		
		
	}
}
