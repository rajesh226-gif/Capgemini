package com.capgemini.casestudy;

public interface IAccount {
	final String BANKNAME = "SBI";
	
	public abstract void withdraw(double amt);
}
