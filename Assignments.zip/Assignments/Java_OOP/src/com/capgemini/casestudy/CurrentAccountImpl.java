package com.capgemini.casestudy;

public class CurrentAccountImpl implements IAccount{
	int accId;
	double minBal = 1000;
	double withdrawAmt;
	double accBal;

	public CurrentAccountImpl() {
		super();
	}
	
	public CurrentAccountImpl(int accId, double withdrawAmt, double accBal) {
		super();
		this.accId = accId;
		this.withdrawAmt = withdrawAmt;
		this.accBal = accBal;
	}
	
	public CurrentAccountImpl(int accId, double minBal, double withdrawAmt, double accBal) {
		super();
		this.accId = accId;
		this.minBal = minBal;
		this.withdrawAmt = withdrawAmt;
		this.accBal = accBal;
	}
	
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public double getMinBal() {
		return minBal;
	}
	public void setMinBal(double minBal) {
		this.minBal = minBal;
	}
	public double getWithdrawAmt() {
		return withdrawAmt;
	}
	public void setWithdrawAmt(double withdrawAmt) {
		this.withdrawAmt = withdrawAmt;
	}
	public double getAccBal() {
		return accBal;
	}
	public void setAccBal(double accBal) {
		this.accBal = accBal;
	}

	@Override
	public void withdraw(double amt) {
		// TODO Auto-generated method stub
		if((accBal - minBal) < amt)
			System.out.println("Insufficient Balance");
		else {
			accBal -= amt;
			System.out.println("withdraw successful");
		}
	}

	@Override
	public String toString() {
		return "CurrentAccountImpl [accId=" + accId + ", minBal=" + minBal + ", withdrawAmt=" + withdrawAmt
				+ ", accBal=" + accBal + "]";
	}
	
}
