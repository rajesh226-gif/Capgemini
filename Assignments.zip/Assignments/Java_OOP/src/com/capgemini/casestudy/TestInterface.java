package com.capgemini.casestudy;

import java.util.Scanner;

public class TestInterface {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		CurrentAccountImpl c = new CurrentAccountImpl();
		System.out.println("Welcome to " + c.BANKNAME);
		System.out.println("Enter the account id : ");
		int accId = sc.nextInt();
		System.out.println("Enter the amount to be withdrawn : ");
		double amt = sc.nextDouble();
		
		IAccount a = new CurrentAccountImpl(101, amt, 2000);
		System.out.println("Thank you for using " + a.BANKNAME + " services");
		a.withdraw(amt);
		
		
		//IAccount a1;
		
		//a1 = a;
		//a1.withdraw(amt);
		
	}
}
