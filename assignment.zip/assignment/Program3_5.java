package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;

public class Program3_5 {

	public void calcExpiryDate(String date, int years, int months) {
		// TODO Auto-generated method stub
		int rem = 0;
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate pDate = LocalDate.parse(date,format);
		int month = pDate.getMonthValue();
		int year = pDate.getYear();
		int dat = pDate.getDayOfMonth();
		int y = year + years;
		int m = month + months;
		
		if(m > 12) {
			int yr = m / 12;
			rem = m - (yr * 12);
			y = y + yr;
			m = rem;
		} 
		System.out.println("Expiry date is : " + dat + "-"+ m + "-" + y);
		
	}

}
