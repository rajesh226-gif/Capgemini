package com.cg.mobile.service;

public class MobileValidator {

}
