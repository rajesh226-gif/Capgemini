package com.cg.mobile.presentation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.service.MobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileUIClass {
	
	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		String res = "";
		do {
			System.out.println("Enter your choice:");
			System.out.println("1.Insert customer and purchase details");
			System.out.println("2.View details of all mobiles");
			System.out.println("3.Delete a mobile");
			System.out.println("4.Search mobile based on price");
			int n = sc.nextInt();
			switch(n) {
			case 1:new MobileUIClass().addCustomer();
				break;
			case 2:new MobileUIClass().viewMobileDetails();
				break;
			case 3:new MobileUIClass().deleteMobile();
				break;
			case 4:new MobileUIClass().searchMobile();
				break;
			default :System.out.println("select the correct option");
			    break;
			}
			System.out.println("Do you want to continue yes/no");
			res = sc.next();
		} while(res.equals("yes"));		
	}
	
	private void searchMobile() throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the price of the mobile to be searched:");
		int price = sc.nextInt();
		MobileService search = new MobileServiceImpl();
		search.searchMobile(price);
		
	}

	private void deleteMobile() throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id of the mobile to be deleted:");
		int id = sc.nextInt();
		MobileService del = new MobileServiceImpl();
		del.deleteMobile(id);	
		
	}

	private void viewMobileDetails() throws Exception {
		// TODO Auto-generated method stub
		
		MobileService view = new MobileServiceImpl();
		view.viewMobileDetails();		
	}

	public void addCustomer() {
		// TODO Auto-generated method stub
		try {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the customer name:");
		String cname = sc.nextLine();
		System.out.println("Enter the mail id:");
		String mailId = sc.nextLine();
		System.out.println("Enter the phone no:");
		String phoneNo = sc.nextLine();
		
		System.out.println("Enter the mobile name:");
		String mobName = sc.nextLine();
		System.out.println("Enter the purchase date");
		String date = sc.next();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date1 = formatter.parse(date);
		
		PurchaseDetails pd = new PurchaseDetails();
		pd.setCname(cname);
		pd.setMailId(mailId);
		pd.setPhoneNo(phoneNo);
		pd.setPurchaseDate(date1);
		pd.setMobileName(mobName);
		String result = new MobileServiceImpl().addCustomer(pd);
		System.out.println(result);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	

}
