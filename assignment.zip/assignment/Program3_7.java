package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Program3_7 {
	
	String firstName;
	String lastName;
	char gender;
	
	public  Program3_7(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}

	public  Program3_7() {
		super();
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "PersonDetails: \n_______________\n\nFirstName:" + firstName + "\nLastName:" + lastName + "\nGender:" + gender;
	}

	public int calculateAge(String dob) {
		// TODO Auto-generated method stub
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate d = LocalDate.parse(dob,format);
		LocalDate end = LocalDate.now();
		
		Period period = d.until(end);
		int age = period.getYears();
		return age;
	}

	public String getFullName() {
		// TODO Auto-generated method stub
		String fname = firstName+" "+lastName;
		return fname;
	}
	
	


}
