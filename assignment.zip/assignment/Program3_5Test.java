package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class Program3_5Test {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the purchase date:");
		String date = sc.next();
		System.out.println("Enter the no of years in which the product will expire:");
		int years = sc.nextInt();
		System.out.println("Enter the no of months in which the product will expire:");
		int months = sc.nextInt();
		
		Program3_5 p1 = new Program3_5();
		p1.calcExpiryDate(date,years,months);
		
	}

}
