package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class Program3_7Test {
	
	public static void main(String[] args) {
		
		Program3_7 p1 = new Program3_7("Sharanya","Arpally",'F');
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the date of birth : ");
		String dob = sc.next();
		int age = p1.calculateAge(dob);
		String fname =  p1.getFullName();
		
		System.out.println(p1);
		System.out.println("Age :"+age);
		System.out.println("Full Name : "+fname);
		
		
	}

}
