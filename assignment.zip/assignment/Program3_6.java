package com.capgemini.assignment.lab3;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.TimeZone;

public class Program3_6 {

	public void findDateTime(String zone) {
		// TODO Auto-generated method stub
		ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of(zone));
		System.out.println(currentTime);
	}

}
