package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class Program3_6Test {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the zone ID:");
		String zone = sc.next();
		
		Program3_6 p = new Program3_6();
		p.findDateTime(zone);
	}

}
